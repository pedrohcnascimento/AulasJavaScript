import React from "react";
import './App.css';

function ListaTarefa({ tarefas, alternarConclusao }) {
  return (
    <ul>
      {tarefas.map((tarefa, index) => (
        <li key={index} className={tarefa.concluida ? "tarefa-concluida" : ""}>
          {tarefa.texto}
          <button
            className="botao-alternar"
            onClick={() => alternarConclusao(index)}
          >
            {tarefa.concluida ? "Desmarcar" : "Concluir"}
          </button>
        </li>
      ))}
    </ul>
  );
}

export default ListaTarefa;