import React from "react";

function adicionarTarefa({input, setInput, adicionarTarefa}) {
    return (
        <div>
            <input
                type="text"
                placeholder="Digite uma tarefa"
                value={input}
                onChange={(e) => setInput(e.target.value)}
            />
            <button onClick={adicionarTarefa}>Adicionar</button>
        </div>
    );
}

export default adicionarTarefa;