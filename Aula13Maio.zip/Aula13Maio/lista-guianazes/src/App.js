import React, { useState, useEffect } from "react";
import './App.css';
import AdicionarTarefa from './AdicionarTarefa';
import ListaTarefa from './listaTarefa';

function App() {
  const [tarefas, setTarefas] = useState([]);
  const [input, setInput] = useState("");

  useEffect(() => {
    const dadosSalvos = localStorage.getItem("tarefas");

    if (dadosSalvos) {
      setTarefas(JSON.parse(dadosSalvos));
    }
  }, []);

  useEffect(() => {
    localStorage.setItem("tarefas", JSON.stringify(tarefas));
  }, [tarefas]);

  const adicionarTarefas = () => {
    if (input.trim()) {
      setTarefas([...tarefas, { texto: input, concluida: false }]);
      setInput("");
    }
  };

  const alternarConclusao = (index) => {
    const novasTarefas = [...tarefas];
    novasTarefas[index].concluida = !novasTarefas[index].concluida;
    setTarefas(novasTarefas);
  };

  const RemoverTarefa = () => {
    setTarefas([]);
  };

  return (
    <div className="App">
      <h1>Lista de Tarefas</h1>
      <p>Total de tarefas pendentes: {tarefas.filter(tarefa => !tarefa.concluida).length}</p>
      <AdicionarTarefa input={input} setInput={setInput} adicionarTarefa={adicionarTarefas} />
      <ListaTarefa tarefas={tarefas} alternarConclusao={alternarConclusao} />
      <button className="limpar" onClick={RemoverTarefa}>Limpar</button>
    </div>
  );
}

export default App;